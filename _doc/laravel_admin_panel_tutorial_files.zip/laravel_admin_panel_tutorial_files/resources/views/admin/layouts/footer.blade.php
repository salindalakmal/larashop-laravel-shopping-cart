    <footer>
        <div class="">
            <p class="pull-right">Bootstrap 3 template by <a>Kimlabs</a>. | Laravel 5 Implementation by <a href="http://www.tutorials.kode-blog.com/laravel-5-admin-panel" target="_blank">Kode Blog Tutorials</a>
                <span class="lead"> <i class="fa fa-paw"></i> Larashop Admin</span>
            </p>
        </div>
        <div class="clearfix"></div>
    </footer>